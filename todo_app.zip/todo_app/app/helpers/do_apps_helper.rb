module DoAppsHelper
end
